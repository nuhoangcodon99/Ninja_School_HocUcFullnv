package huydat.template;

public class ItemOptionTemplate {
    public int id;
    public String name;
    public byte type;
}
