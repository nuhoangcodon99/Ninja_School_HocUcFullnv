package huydat.template;

public class NpcTemplate {
    public int npcTemplateId;
    public String name;
    public short headId;
    public short bodyId;
    public short legId;
    public String[][] menu;
}
