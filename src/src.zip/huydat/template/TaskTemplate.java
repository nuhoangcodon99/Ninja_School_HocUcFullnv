package huydat.template;

public class TaskTemplate {
    public short taskId;
    public String name;
    public String detail;
    public String[] subNames;
    public short[] counts;
}
