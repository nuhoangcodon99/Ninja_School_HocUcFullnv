package huydat.template;

import java.util.ArrayList;

public class EffectTemplate {
    public int id;
    public byte type;
    public String name;
    public short iconId;
    public static ArrayList<EffectTemplate> entrys = new ArrayList();
}
