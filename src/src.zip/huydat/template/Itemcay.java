/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package huydat.template;

/**
 *
 * @author HUY DAT
 */
public class Itemcay {
    public String name;
    public int x;
    public int y;
}
