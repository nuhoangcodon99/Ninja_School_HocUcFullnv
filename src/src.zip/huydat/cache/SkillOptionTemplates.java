package huydat.cache;

public class SkillOptionTemplates {
    public int id;
    public String name;
}
