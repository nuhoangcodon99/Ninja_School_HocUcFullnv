package huydat.real;

public class User {
    public int id;
    public String username = null;
    public int role = 0;
    public int online = 0;
    public int luong = -1;
    public int status = -1;
    public String[] sortNinja = new String[3];

}
