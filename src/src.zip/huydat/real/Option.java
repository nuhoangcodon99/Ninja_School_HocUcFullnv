package huydat.real;

public class Option {
    public int id;
    public int param;

    public Option(int id, int par) {
        this.id = id;
        this.param = par;
    }
}
