package huydat.real;

public class PartyPlease {
    public int partyId;
    public int charID;
    public int timeLive;

    public PartyPlease(int partyId, int charID, int timeLive) {
        this.partyId = partyId;
        this.charID = charID;
        this.timeLive = timeLive;
    }
}
