package huydat.real;

public class ItemDefault extends Item{
    public ItemDefault() {
        this.id = -1;
    }
}
