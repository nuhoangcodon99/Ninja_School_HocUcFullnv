package huydat.real;

public class Language {
    public static String MAX_MEMBER_PARTY = "Số lượng thành viên nhóm đã tốt đa.";
    public static String SET_LEADER_PARTY = " đã được lên làm nhóm trưởng.";
    public static String KICKED_OUT_PARTY = " đã bị đuổi ra khỏi nhóm.";
    public static String LEFT_PARTY = " đã rời khỏi nhóm.";
    public static String KICKED_ME_PARTY = "Bạn đã bị đuổi ra khỏi nhóm.";
    public static String NOT_ENOUGH_BAG = "Hành trang không đủ chỗ trống.";
    public static String NOT_ENOUGH_BOX = "Rương không đủ chỗ trống.";
    public static String CANCEL_TRADE = "Giao dịch đã bị huỷ.";
    public static String NOT_IN_ZONE = "Người chơi không ở cùng khu vực.";
    public static String SEND_MESS_LOI_DAI = "Ta đã gửi lời mời của con rồi.";
    public static String NAME_LOI_DAI = "Ngươi lại muốn thách đấu chính mình ư?";
    public static String TEST_ALREADY = "Bạn đã có yêu cầu tỷ thí từ trước. Vui lòng chờ cho đến khi yêu cầu tỷ thí được kết thúc";
    public static String NOT_CUU_SAT = "Không thể cừu sát người khác tại trường hoặc làng";
    public static String MAX_HIEU_CHIEN = "Điểm hiếu chiến của bạn quá cao, không thể sử dụng chức năng này!";
    public static String MAX_CUU_SAT = "Bạn đang cừu sát người khác không thể cùng lúc cừu sát nhiều người";
    public static String DO_NOT_CHANGE_PK = "Bạn không thể thay đổi trạng thái PK tại đây";
    public static String NOT_ENOUGH_DISTANCE = "Khoảng cách quá xa";
    public static String MAX_QUANTITY_CLAN = "Gia tộc đã đạt số lượng thành viên tối đa";
    public static String HAVE_LEARNED_SKILL = "Bạn đã học kỹ năng này rồi";
    public static String MAX_EXP_DOWN = "Điểm âm kinh nghiệm hoặc điểm hiếu chiến quá cao không thể sử dụng vật phẩm này";
    public static String IS_THU_THAN = "Bạn đang trong chế độ thứ thân, không thể sử dụng chức năng này";
    public static String END_EVENT = "Sự kiện này đã kết thúc, không còn có thể sử dụng vật phẩm này được nữa!";
    public static String NOT_FOR_PHAN_THAN = "Chức năng này không dành cho phân thân!";

}
