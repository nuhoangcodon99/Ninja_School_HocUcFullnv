package huydat.real;

public class Friend {
    public String friendName;
    public byte type;

    public Friend(String friendName, byte type) {
        this.friendName = friendName;
        this.type = type;
    }
}
