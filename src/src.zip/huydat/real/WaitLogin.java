package huydat.real;

public class WaitLogin {
    public String username;
    public long timeWait;

    public WaitLogin(String username, long timeWait) {
        this.username = username;
        this.timeWait = timeWait;
    }
}
