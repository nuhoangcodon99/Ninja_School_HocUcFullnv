package huydat.stream;

public class ClearSession implements Runnable{
    public void run() {
//        try {
//            Manager.isClearSession = true;
//            if (Manager.isClearSession) {
//                Client.gI().Clear();
//                Manager.isClearSession = false;
//                System.out.println("-------------------------- Clear session: "+Manager.isClearSession+" -----------------------------------" +!Thread.currentThread().isInterrupted());
//                return;
//            }
//        } catch (Exception e) {
//            Manager.isClearSession = false;
//            e.printStackTrace();
//            return;
//        }
    }
}
